package com.example.prezentownik.models;

public class Person {
}
