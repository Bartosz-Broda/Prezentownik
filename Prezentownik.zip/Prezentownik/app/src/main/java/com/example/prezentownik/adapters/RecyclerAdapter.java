package com.example.prezentownik.adapters;

public class RecyclerAdapter {
}
